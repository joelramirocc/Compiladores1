#ifndef __TOKENS_H__
#define __TOKENS_H__

enum class Token {
    Num,
    Add,
    Eof,
    PClosed,
    Div,
    POpen,
    SemiColon,
    Sub,
    Asterisco,
};
#endif